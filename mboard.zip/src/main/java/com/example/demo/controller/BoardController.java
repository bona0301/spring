package com.example.demo.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.*;
import com.example.demo.entity.*;
import com.example.demo.service.*;

@RestController
public class BoardController {
	@Autowired
	private BoardService service;
	
	@PostMapping(value="/board/new", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Board> write(@ModelAttribute WriteDto dto) {
		return ResponseEntity.ok(service.write(dto));
	}

	@GetMapping(value="/board/all", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Board>> list() {
		return ResponseEntity.ok(service.list());
	}

	@GetMapping(value="/board/read", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Board> read(@RequestParam(defaultValue="0") Integer bno) {
		Optional<Board> board = service.read(bno);
		if(board.isEmpty())
			return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
		return ResponseEntity.ok(board.get());
	}
}
