package com.example.demo.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;

import com.example.demo.entity.*;

@Mapper
public interface BoardDao {
	@Insert("insert into board values(#{bno}, #{title}, #{content}, #{writer}, sysdate, 0)")
	public int save(Board board);
	
	@Select("select * from board")
	public List<Board> findAll();
	
	@Select("select * from board where bno=#{bno}")
	public Optional<Board> findById(Integer bno);
}
