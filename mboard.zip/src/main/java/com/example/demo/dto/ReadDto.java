package com.example.demo.dto;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

import lombok.*;

@Getter
@AllArgsConstructor
public class ReadDto {
	private Integer bno;
	private String title;
	private String content;
	private String writer;
	@JsonFormat(pattern="yyyy-MM-dd hh:mm:ss")
	private Date writeTime;
	private Integer readCnt;
}
