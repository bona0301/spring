package com.example.demo.dto;

import com.example.demo.entity.*;

import lombok.*;

@Data
@AllArgsConstructor
public class WriteDto {
	private String title;
	private String content;
	private String writer;
	
	public Board toEntity() {
		return Board.builder().title(title).content(content).writer(writer).build();
	}
}



