package com.example.demo.entity;

import java.util.*;

import com.example.demo.dto.*;
import com.fasterxml.jackson.annotation.*;

import lombok.*;

@Getter
@EqualsAndHashCode
@ToString
@Builder
public class Board {
	private Integer bno;
	private String title;
	@JsonIgnore
	private String content;
	private String writer;
	@JsonFormat(pattern="yyyy-MM-dd hh:mm:ss")
	private Date writeTime;
	private Integer readCnt;
	
	
	public void init(int bno) {
		this.bno = bno;
	}
	
	public void increaseReadCnt() {
		this.readCnt++;
	}
	
	public void update(UpdateDto dto) {
		this.title = dto.getTitle();
		this.content = dto.getContent();
	}
}


