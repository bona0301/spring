package com.example.demo.service;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.example.demo.dao.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;

@Service
public class BoardService {
	@Autowired
	private BoardDao dao;
	private Integer bno = 1;
	
	public Board write(WriteDto dto) {
		Board board = dto.toEntity();
		board.init(bno++);
		dao.save(board);
		return board;
	}

	public List<Board> list() {
		return dao.findAll();
	}

	public Optional<Board> read(Integer bno) {
		return dao.findById(bno);
	}

}
