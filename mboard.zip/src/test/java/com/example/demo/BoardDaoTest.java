package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.context.*;
import org.springframework.transaction.annotation.*;

import com.example.demo.dao.*;
import com.example.demo.entity.*;

@SpringBootTest
public class BoardDaoTest {
	@Autowired
	private BoardDao dao;
	
	//@Test
	public void initTest() {
		assertNotNull(dao);
	}
	
	@Transactional
	//@Test
	public void saveAndReadTest() {
		dao.save(Board.builder().bno(1).title("aaa").content("bbb").writer("spring").build());
		Board board = dao.findById(1).get();
		System.out.println(board);
	}
	
	@Test
	public void findAllTest() {
		assertEquals(dao.findAll().size(), 0);
	}
}
